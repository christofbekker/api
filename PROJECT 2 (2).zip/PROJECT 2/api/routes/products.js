const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const Product = require('../models/products');

router.get('/', (req, res, next) => {
    Product.find()
        .exec()
        .then(docs => {
            console.log(docs);
            res.status(200).json(docs);
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            })
        });
});

router.post('/', (req, res, next) => {

    const product = new Product({
        _id: new mongoose.Types.ObjectId(),
        name: req.body.name,
        password: req.body.password,
        idMD: req.body.id,
        Email: req.body.email,
        Phone: req.body.number
    });
    product.save().then(result => {
            console.log(result);
            res.status(201).json({
                message: 'Handling POST requests to /products',
                createdProduct: result
            })
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: err
            });
        });

    router.get('/:productId', (req, res, next) => {
        const id = req.params.productId;
        Product.findById(id)
            .exec()
            .then(doc => {
                console.log("From DB:", doc);
                if (doc) {
                    res.status(200).json(doc);
                } else {
                    res.status(404).json({
                        message: 'No entry found for ID'
                    });
                }
            })
            .catch(err => {
                console.log(err);
                res.status(500).json({ error: err });
            })

    });

    router.patch('/:productId', (req, res, next) => {
        res.status(200).json({
            message: 'Updated Product'
        })
    });

    router.delete('/:productId', (req, res, next) => {
        res.status(200).json({
            message: 'Deleted Product'
        })
    });

    //module.exports = router;


});

var Email = "";
var Id = "";
var Phone = "";

router.post('/extraction', (req, res, next) => {

    var line = req.body.list;

    var regexMail = /\S+@\S+\.\S+/;
    var emailMatch = regexMail.exec(line);

    if (emailMatch == null) {

    } else {
        var emailValid = validateEmail(emailMatch[0]);

        if (emailValid == true) {
            Email = emailMatch[0];

        } else {
            res.status(200).json({

            });
        }
    }


    var IdNum = luhnCheck(line);
    if (IdNum == true) {
        Id = line;
        console.log("ID: " + line);
    } else {
        console.log("Not an ID");
    }

    var numberP = validatePhone(line);

    if (numberP == true) {
        Phone = line;
    }

    res.status(200).json({
        message: 'Validated Fields',
        Email: Email,
        IDNumber: Id,
        Phone: Phone
    })

});

module.exports = router;

function validateEmail(email) {
    var re = /\S+@\S+\.\S+/;
    return re.test(email);
}

const luhnCheck = num => {
    let arr = (num + '')
        .split('')
        .reverse()
        .map(x => parseInt(x));
    let lastDigit = arr.splice(0, 1)[0];
    let sum = arr.reduce((acc, val, i) => (i % 2 !== 0 ? acc + val : acc + ((val * 2) % 9) || 9), 0);
    sum += lastDigit;
    return sum % 10 === 0;
};

function validatePhone(number) {
    var re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
    return re.test(number);
}