const mongoose = require('mongoose');

const productSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    name: String,
    password: String,
    idMD: String,
    Email: String,
    Phone: String
});

module.exports = mongoose.model('Product', productSchema);

const UserSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    Username: String,
    Password: String,
    Email: String
});

module.exports = mongoose.model('Users', UserSchema);